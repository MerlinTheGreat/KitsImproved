package me.__Merlin__.Commands;

import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.__Merlin__.Handlers.KitMessages;
import me.__Merlin__.Handlers.Kits;
import me.__Merlin__.Handlers.NoPermission;
import me.__Merlin__.Handlers.Selected;
import me.__Merlin__.KitImproved.Main;
import net.md_5.bungee.api.ChatColor;

public class KitCommand  implements CommandExecutor
{
	Main plugin;
	
	public KitCommand(Main instance) 
	{
		this.plugin = instance;
	}
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String string, String[] args) 
	{
		if(!(sender instanceof Player))
		{
			sender.sendMessage(ChatColor.RED + "I can't let you do this jon!");
			return true;
		}
		Player p = (Player)sender;
		if(cmd.getName().equalsIgnoreCase("kit"))
		{
			if (args.length !=1 )
			{
				KitMessages.kits(p);
				return true;
			}
			if (args.length == 1) {
				if (args[0].equalsIgnoreCase("knight"))
				{
					if (p.hasPermission("kit.knight")) 
					{
						if((this.plugin.switcherkit.contains(p.getName())) ||
						(this.plugin.archerkit.contains(p.getName())) ||
						(this.plugin.hulkkit.contains(p.getName())))
                          {
							Selected.alreadySelected(p);
                          }
						else
						{
							Kits.horseKit(p);
							p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6Kit &7> &fYou have selected the &eKnight &fkit!"));
							p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 1.0F, 0.0F);
							
							this.plugin.archerkit.add(p.getName());
							return true;
						}
				}
					else { 
						NoPermission.nopermKit(p);
					}
			}
		
				else if (args[0].equalsIgnoreCase("hulk"))
				{
					if (p.hasPermission("kit.hulk")) 
					{
						if((this.plugin.switcherkit.contains(p.getName())) ||
						(this.plugin.archerkit.contains(p.getName())) ||
						(this.plugin.hulkkit.contains(p.getName())))
                          {
							Selected.alreadySelected(p);
                          }
						else
						{
							Kits.HulkKit(p);
							p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6Kit &7> &fYou have selected the &eHulk &fkit!"));
							p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 1.0F, 0.0F);
							
							this.plugin.hulkkit.add(p.getName());
							return true;
						}
				}
					else { 
						NoPermission.nopermKit(p);
					}
			}
				if (args[0].equalsIgnoreCase("switcher"))
				{
					if (p.hasPermission("kit.switcher")) 
					{
						if((this.plugin.switcherkit.contains(p.getName())) ||
						(this.plugin.archerkit.contains(p.getName())) ||
						(this.plugin.hulkkit.contains(p.getName())))
                          {
							Selected.alreadySelected(p);
                          }
						else
						{
							Kits.SwitcherKit(p);
							p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6Kit &7> &fYou have selected the &eSwitcher &fkit!"));
							p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 1.0F, 0.0F);
							
							this.plugin.switcherkit.add(p.getName());
							return true;
						}
				}
					else { 
						NoPermission.nopermKit(p);
					}
			}
			}
		}
		return false;
	}
}
			
