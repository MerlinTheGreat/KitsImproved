package me.__Merlin__.Listeners;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import me.__Merlin__.Handlers.AddHorseItem;
import me.__Merlin__.Handlers.AutoRespawn;
import me.__Merlin__.Handlers.Cooldown;
import me.__Merlin__.KitImproved.Main;
public class Default implements Listener {
	Main plugin; 
	public Default(Main instance)
	{
		this.plugin = instance;
	}
    @EventHandler
    public void onJoin(PlayerJoinEvent e)
    {
    	Player p = e.getPlayer();
    	
    	e.setJoinMessage(null);
    	if(this.plugin.getConfig().getBoolean("Join.Join-MOTD"))
    	{
    		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8&m---------------------------"));
    		p.sendMessage("");
    		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8> &cThis server uses KitsImproved and &fwas developed by &e__Merlin__&f!"));
    		p.sendMessage("");
    		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8&m---------------------------"));
    		p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 0.0F);
    	}
    }
    @EventHandler
    public void onHorsePlace(PlayerInteractEvent e) 
    {
    	final Player p = e.getPlayer();
    			
    	Action a = e.getAction();
    	ItemStack is = e.getItem();
    	if((a == Action.PHYSICAL) || (is == null) || (is.getType() == Material.AIR)) {
    		return;
    	} 
    	if (is.getType() == Material.SADDLE)
    	{
    	Horse h = (Horse)p.getWorld().spawnEntity(p.getLocation(), EntityType.HORSE);
    	h.setTamed(true);
    	h.setOwner(p);
    	h.getInventory().setSaddle(new ItemStack(Material.SADDLE, 1));
    	h.setCustomName(ChatColor.RED + p.getName() + "'s" + ChatColor.WHITE + "Horse");
    	h.setCustomNameVisible(true);
    	h.setPassenger(p);
    	p.getInventory().remove(Material.SADDLE);
    	p.updateInventory();
    }
    	if (is.getType() == Material.NETHER_STAR)
    	{
    		if (this.plugin.hulkkitcool.contains(p.getName())) 
    		{
    			Cooldown.cooldownMSG(p);
    			return;
    		}
    		this.plugin.hulkkitcool.add(p.getName());
    		for (Entity near : p.getNearbyEntities(5.0D, 5.0D, 5.0D)) 
    		{
    			if ((near instanceof Player)) {
    				near.setVelocity(new Vector(0, 1, 0).multiply(1.5D));
    			}
    		}
    		this.plugin.getServer().getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
    				{
    			public void run()
    			{
    				Default.this.plugin.hulkkitcool.remove(p.getName());
    			}
    		}, 300L);
    	  }
    	}
    
    @EventHandler
    public void onHorseRide(VehicleExitEvent e) 
    {
    final  Player p = (Player)e.getExited();
    if(((e.getVehicle() instanceof Horse)) || ((e.getExited() instanceof Player)))
    {
    	e.getVehicle().remove();
    	p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6Horses &7&l> &fYour Horse has disappeared Magically as you disown it!"));
    	p.playSound(p.getLocation(), Sound.ENTITY_HORSE_DEATH, 1.0F, 0.0F);
    	this.plugin.getServer().getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
    			{
    		public void run()
    		{
    			AddHorseItem.horseItem(p);
    		}
    	}, 20L);
    }
  }
    
    @EventHandler
    public void onDeath(PlayerDeathEvent e) 
    {
        				Player p = e.getEntity();
        				e.getDrops().clear();
        				ClearGroup(p.getName());
        				AutoRespawn.onDeath(p);
    	
    }
    @EventHandler
    public void onLeave(PlayerQuitEvent e) 
    {
    	Player p = e.getPlayer();
    	e.setQuitMessage(null);
    }
    
    public void ClearGroup(String name)
    {
    	while (this.plugin.archerkit.contains(name)) {
    		this.plugin.archerkit.remove(name);
    	}
    	while (this.plugin.hulkkit.contains(name)) {
    		this.plugin.hulkkit.remove(name);
    	}
    	while (this.plugin.hulkkitcool.contains(name)) {
    		this.plugin.hulkkitcool.remove(name);
    	}
    	while (this.plugin.switcherkit.contains(name)) {
    		this.plugin.switcherkit.remove(name);
    	}
    }
    
}