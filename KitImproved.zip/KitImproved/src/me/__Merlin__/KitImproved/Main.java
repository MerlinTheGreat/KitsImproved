package me.__Merlin__.KitImproved;

import java.util.ArrayList;

import org.bukkit.plugin.java.JavaPlugin;

import me.__Merlin__.Commands.KitCommand;
import me.__Merlin__.Listeners.Default;

public class Main extends JavaPlugin
{
 public ArrayList<String> hulkkit = new ArrayList();
 public ArrayList<String> hulkkitcool = new ArrayList();
 public ArrayList<String> archerkit = new ArrayList();
 public ArrayList<String> switcherkit = new ArrayList();
 
 public void onEnable()
 {
	 getLogger().info("has been enabled!");
	 getServer().getPluginManager().registerEvents(new Default (this), this);
	 getCommand();
	 getConfig().options().copyDefaults(true);
	 saveDefaultConfig();
 }
 public void onDisable() 
 {
	 getLogger().info("has been Disabled!");
	 
 }
 public void getCommand() 
 {
	 getCommand("kit").setExecutor(new KitCommand(this));
 }
}
