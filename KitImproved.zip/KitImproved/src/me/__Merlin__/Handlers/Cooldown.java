package me.__Merlin__.Handlers;

import org.bukkit.Sound;
import org.bukkit.entity.Player;

import net.md_5.bungee.api.ChatColor;

public class Cooldown 
{
	public static void cooldownMSG(Player p)
	{
		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6Cooldowns &7> &fYou currently have a cooldown for this Ability!"));
		p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BASS, 1.0F, 0.0F);
	}

}
