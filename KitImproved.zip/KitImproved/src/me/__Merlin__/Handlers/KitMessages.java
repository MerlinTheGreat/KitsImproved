package me.__Merlin__.Handlers;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class KitMessages 
{
	public static void kits(Player p)
	{
		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8&m---------------------------"));
		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8> &cKits&7:"));
		p.sendMessage("");
		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8> &e/kit Knight"));
		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8> &e/kit Switcher"));
		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8> &e/kit hulk"));
		p.sendMessage("");
		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8&m---------------------------"));
		
		p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 1.0F, 0.0F);
		
		
	}

}
