package me.__Merlin__.Handlers;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class NoPermission 
{
	public static void nopermKit(Player p)
	{
		
	
	p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&cError &7> &f You don't have permission to use this kit! Perhaps you must be a donor to use it?"));
	p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BASS, 1.0F, 0.0F);
	
	}
}
