package me.__Merlin__.Handlers;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class AddHorseItem 
{
 public static void horseItem(Player p)
 {
	 ItemStack horseegg = new ItemStack(Material.SADDLE, 1);
	 horseegg.addUnsafeEnchantment(Enchantment.DURABILITY, 10);
	 ItemMeta horseMeta = horseegg.getItemMeta();
	 horseMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&3&lA Magical Saddle! :c"));
	 horseegg.setItemMeta(horseMeta);
	 
	 p.getInventory().addItem(new ItemStack[] { horseegg });
	 
	 
	 p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6Horses &7&l> &fYou have recieved a Magical Mysterious Saddle!"));
	 p.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_BLAST, 1.0F, 0.0F);
 }
}
