package me.__Merlin__.Handlers;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class Selected {
	
	public static void alreadySelected(Player p)
	{
		p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6Kits &7> &fYou already &eSelected &fa kit!"));
		p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BASS, 1.0F, 0.0F);
	}

}
