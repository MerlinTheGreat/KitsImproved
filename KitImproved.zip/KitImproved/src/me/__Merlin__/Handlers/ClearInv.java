package me.__Merlin__.Handlers;

import org.bukkit.entity.Player;

public class ClearInv 
{
	public static void ClearInv(Player p)
	{
		p.getInventory().setArmorContents(null);
		p.getInventory().clear();
	}

}
