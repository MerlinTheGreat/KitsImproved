package me.__Merlin__.Handlers;

import org.bukkit.entity.Player;

public class AutoRespawn 
{
	public static void onDeath(Player p)
	{
		if(p.isDead()) {
			try 
			{
				Object nmsPlayer = p.getClass().getMethod("getHandle", new Class[0]).invoke(p,  new Object[0]);
				Object packet =
						Class.forName(nmsPlayer.getClass().getPackage().getName() + ".PacketPlayInClientCommand").newInstance();
						Class<?> enumClass = Class.forName(nmsPlayer.getClass().getPackage().getName() + ".EnumClientCommand");
						Object[] arrayofObject;
						int j = (arrayofObject = enumClass.getEnumConstants()).length;
						for (int i = 0; i <j; i ++)
						{
							Object ob = arrayofObject[i];
							if (ob.toString().equals("PERFORM_RESPAWN")) {
								packet =
										
										packet.getClass().getConstructor(new Class[] { enumClass }).newInstance(new Object[] {
												ob });
										}
							}
						Object con = nmsPlayer.getClass().getField("playerConnection").get(nmsPlayer);
						con.getClass().getMethod("a", new Class[] { packet.getClass() }).invoke(con,  new Object[] { packet });
						}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}

}
