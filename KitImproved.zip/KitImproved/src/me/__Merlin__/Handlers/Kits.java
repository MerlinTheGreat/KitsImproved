package me.__Merlin__.Handlers;

import java.util.Random;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;

import me.__Merlin__.KitImproved.Main;
import net.md_5.bungee.api.ChatColor;

public class Kits 
{
	static Main plugin;
	static Random random = new Random();
	private static ItemStack[] foods = { new ItemStack(Material.APPLE, 32),
			new ItemStack(Material.COOKED_BEEF, 32),
			new ItemStack(Material.COOKED_CHICKEN, 32),
			new ItemStack(Material.PUMPKIN_PIE, 32),
			new ItemStack(Material.COOKED_FISH, 32),
			new ItemStack(Material.COOKED_MUTTON, 32) };
	
	
	public Kits(Main instance)
	{
		plugin = instance;
	}
	public static void horseKit(Player p)
	{
		ClearInv.ClearInv(p);
	
		ItemStack helmet = new ItemStack(Material.LEATHER_HELMET, 1);
		ItemMeta helmetMeta = helmet.getItemMeta();
		helmetMeta.setDisplayName(ChatColor.RED + "Knight's Shiny Armor");
		((LeatherArmorMeta)helmetMeta).setColor(Color.RED);
        helmet.setItemMeta(helmetMeta);
        
        p.getInventory().setHelmet(helmet);
        
        ItemStack chestplate = new ItemStack(Material.LEATHER_CHESTPLATE, 1);
		ItemMeta chestplateMeta = chestplate.getItemMeta();
		chestplateMeta.setDisplayName(ChatColor.RED + "Knight's Shiny Armor");
		((LeatherArmorMeta)chestplateMeta).setColor(Color.BLACK);
        chestplate.setItemMeta(chestplateMeta);
        
        p.getInventory().setChestplate(chestplate);
        
        ItemStack legs = new ItemStack(Material.LEATHER_LEGGINGS, 1);
		ItemMeta legsMeta = legs.getItemMeta();
		legsMeta.setDisplayName(ChatColor.RED + "Knight's Shiny Armor");
		((LeatherArmorMeta)legsMeta).setColor(Color.RED);
        legs.setItemMeta(legsMeta);
        
        p.getInventory().setLeggings(legs);
        
        ItemStack boots = new ItemStack(Material.LEATHER_BOOTS, 1);
		ItemMeta bootsMeta = boots.getItemMeta();
		bootsMeta.setDisplayName(ChatColor.RED + "Knight's Shiny Armor");
		((LeatherArmorMeta)bootsMeta).setColor(Color.BLACK);
        boots.setItemMeta(bootsMeta);
        
        p.getInventory().setBoots(boots);
        
        ItemStack sword = new ItemStack(Material.STONE_SWORD, 1);
        ItemMeta swordMeta = sword.getItemMeta();
      	swordMeta.setDisplayName(ChatColor.RED + "Knight's Blade");
        sword.setItemMeta(swordMeta); 
        
        p.getInventory().addItem(new ItemStack[] { sword });
        
       
        ItemStack food = foods[random.nextInt(5)];
        ItemMeta foodMeta = food.getItemMeta();
        foodMeta.setDisplayName(ChatColor.RED + "Knights Meal");
        food.setItemMeta(foodMeta);
        
        p.getInventory().addItem(new ItemStack[] { food });
        
        ItemStack horseegg = new ItemStack(Material.SADDLE, 1);
        horseegg.addUnsafeEnchantment(Enchantment.DURABILITY, 10);
        ItemMeta horseMeta = horseegg.getItemMeta();
        horseMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&3&lA Magical Saddle! :c"));
        horseegg.setItemMeta(horseMeta);
        
        p.getInventory().addItem(new ItemStack[] {horseegg });

}
	public static void HulkKit(Player p)
	{
		ClearInv.ClearInv(p);
	
		ItemStack helmet = new ItemStack(Material.LEATHER_HELMET, 1);
		ItemMeta helmetMeta = helmet.getItemMeta();
		helmetMeta.setDisplayName(ChatColor.GREEN + "Hulk's Skin");
		((LeatherArmorMeta)helmetMeta).setColor(Color.GREEN);
        helmet.setItemMeta(helmetMeta);
        
        p.getInventory().setHelmet(helmet);
        
        ItemStack chestplate = new ItemStack(Material.LEATHER_CHESTPLATE, 1);
		ItemMeta chestplateMeta = chestplate.getItemMeta();
		chestplateMeta.setDisplayName(ChatColor.GREEN + "Hulk's Skin");
		((LeatherArmorMeta)chestplateMeta).setColor(Color.GREEN);
        chestplate.setItemMeta(chestplateMeta);
        
        p.getInventory().setChestplate(chestplate);
        
        ItemStack legs = new ItemStack(Material.LEATHER_LEGGINGS, 1);
		ItemMeta legsMeta = legs.getItemMeta();
		legsMeta.setDisplayName(ChatColor.GREEN + "Hulk's Skin");
		((LeatherArmorMeta)legsMeta).setColor(Color.GREEN);
        legs.setItemMeta(legsMeta);
        
        p.getInventory().setLeggings(legs);
        
        ItemStack boots = new ItemStack(Material.LEATHER_BOOTS, 1);
		ItemMeta bootsMeta = boots.getItemMeta();
		bootsMeta.setDisplayName(ChatColor.GREEN + "Hulk's Skin");
		((LeatherArmorMeta)bootsMeta).setColor(Color.GREEN);
        boots.setItemMeta(bootsMeta);
        
        p.getInventory().setBoots(boots);
        
        ItemStack sword = new ItemStack(Material.IRON_SWORD, 1);
        ItemMeta swordMeta = sword.getItemMeta();
      	swordMeta.setDisplayName(ChatColor.GREEN + "Hulk's Fists");
        sword.setItemMeta(swordMeta); 
        
        p.getInventory().addItem(new ItemStack[] { sword });
        
       
        ItemStack food = foods[random.nextInt(5)];
        ItemMeta foodMeta = food.getItemMeta();
        foodMeta.setDisplayName(ChatColor.GREEN + "Hulk's Chewy Bites");
        food.setItemMeta(foodMeta);
        
        p.getInventory().addItem(new ItemStack[] { food });
        
       ItemStack netherstar = new ItemStack(Material.NETHER_STAR, 1);
       netherstar.addUnsafeEnchantment(Enchantment.DURABILITY, 10);
       ItemMeta netherstarMeta = netherstar.getItemMeta();
       netherstarMeta.setDisplayName(ChatColor.GREEN + " Click to send players into the air! :o");
       netherstar.setItemMeta(netherstarMeta);
       
       p.getInventory().addItem(new ItemStack[] { netherstar });
       
	
	
}
	public static void SwitcherKit(Player p)
	{
		ClearInv.ClearInv(p);
	
		ItemStack helmet = new ItemStack(Material.IRON_HELMET, 1);
		helmet.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
		ItemMeta helmetMeta = helmet.getItemMeta();
		helmetMeta.setDisplayName(ChatColor.YELLOW + "Switcher's Suit");
        helmet.setItemMeta(helmetMeta);
        
        p.getInventory().setHelmet(helmet);
        
        ItemStack chestplate = new ItemStack(Material.LEATHER_CHESTPLATE, 1);
		ItemMeta chestplateMeta = chestplate.getItemMeta();
		chestplateMeta.setDisplayName(ChatColor.YELLOW + "Switcher's Suit");
        chestplate.setItemMeta(chestplateMeta);
        
        p.getInventory().setChestplate(chestplate);
        
        ItemStack legs = new ItemStack(Material.LEATHER_LEGGINGS, 1);
		ItemMeta legsMeta = legs.getItemMeta();
		legsMeta.setDisplayName(ChatColor.YELLOW + "Switcher's Suit");
        legs.setItemMeta(legsMeta);
        
        p.getInventory().setLeggings(legs);
        
        ItemStack boots = new ItemStack(Material.LEATHER_BOOTS, 1);
        boots.addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
		ItemMeta bootsMeta = boots.getItemMeta();
		bootsMeta.setDisplayName(ChatColor.YELLOW + "Switcher's Suit");
        boots.setItemMeta(bootsMeta);
        
        p.getInventory().setBoots(boots);
        
        ItemStack sword = new ItemStack(Material.IRON_SWORD, 1);
        ItemMeta swordMeta = sword.getItemMeta();
      	swordMeta.setDisplayName(ChatColor.YELLOW + "Switcher's  Staff");
        sword.setItemMeta(swordMeta); 
        
        p.getInventory().addItem(new ItemStack[] { sword });
        
       
        ItemStack food = foods[random.nextInt(5)];
        ItemMeta foodMeta = food.getItemMeta();
        foodMeta.setDisplayName(ChatColor.RED + "Switchers Tele Snacks");
        food.setItemMeta(foodMeta);
        
        p.getInventory().addItem(new ItemStack[] { food });
}
}